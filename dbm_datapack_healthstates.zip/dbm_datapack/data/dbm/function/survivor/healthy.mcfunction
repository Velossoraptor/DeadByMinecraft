# Set speed size and tags for healthy
# Untested
execute as @e[team=Survivor, scores={health=5..6}, tag=injured] run tag @s remove injured
execute as @e[team=Survivor, scores={health=5..6}, tag=downed] run tag @s remove downed
execute as @e[team=Survivor, scores={health=5..6}] unless entity @s[tag=healthy] run tag @s add healthy
execute as @e[team=Survivor, scores={health=5..6}] run attribute @s scale base reset
execute as @e[team=Survivor, scores={health=5..6}] run attribute @s movement_speed base reset
# execute as @e[team=Survivor, scores={health=5..6}] run say healthy