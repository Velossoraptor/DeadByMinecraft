# Set speed size and tags for injured
# Untested
execute as @e[scores={health=3..4}, tag=healthy] run tag @s remove healthy
execute as @e[scores={health=3..4}, tag=downed] run tag @s remove downed
execute as @e[scores={health=3..4}] unless entity @s[tag=injured] run tag @s add injured
execute as @e[scores={health=3..4}] run attribute @s scale base reset
execute as @e[scores={health=3..4}] run attribute @s movement_speed base reset
# execute as @e[scores={health=3..4}] run say injured